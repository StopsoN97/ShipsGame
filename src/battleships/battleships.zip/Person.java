package battleships;

public class Person {
        public String login;
        public String password;
        
        public Person()
	{

	}
}
